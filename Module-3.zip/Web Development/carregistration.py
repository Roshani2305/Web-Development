#!C:\Users\hp\AppData\Local\Programs\Python\Python39\python.exe
import cgi
import mysql.connector

print("Content-type: text/html")
print()

con=mysql.connector.connect(host='localhost',user='root',password='roshani1306',database='automobileshowroomdb')
curs=con.cursor()

form=cgi.FieldStorage()
CarName=form.getvalue("cnm")
CarCompany=form.getvalue("cmpy")
CarType=form.getvalue("ctype")
FuelType=form.getvalue("ftype")
EngineCapacity=form.getvalue("cap")
Price=form.getvalue("inr")

curs.execute("insert into cars values('%s','%s','%s','%s','%s','%s')" %(CarName,CarCompany,CarType,FuelType,EngineCapacity,Price))
con.commit()

print("<h3>Car registration successful</h3>")
print("<a href='index.html'>Home</a>")

con.close()