#!C:\Users\hp\AppData\Local\Programs\Python\Python39\python.exe
import cgi
import mysql.connector

print("Content-type: text/html")
print()

con=mysql.connector.connect(host='localhost',user='root',password='roshani1306',database='automobileshowroomdb')
curs=con.cursor()

form=cgi.FieldStorage()
name=form.getvalue("nm")
userid=form.getvalue("uid")
email=form.getvalue("email")
password=form.getvalue("pass")
repassword=form.getvalue("repwd")
mobileno=form.getvalue("mobno")
state=form.getvalue("stte")
city=form.getvalue("cty")

curs.execute("insert into customers values('%s','%s','%s','%s','%s','%s','%s','%s')" %(name,userid,email,password,repassword,mobileno,state,city))
con.commit()

print("<h3>User registration successful</h3>")
print("<a href='index.html'>Home</a>")

con.close()