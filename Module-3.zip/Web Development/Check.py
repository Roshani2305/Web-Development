#!C:\Users\hp\AppData\Local\Programs\Python\Python39\python.exe
import cgi
import mysql.connector as mycon

print("Content-type: text/html")
print()

con=mycon.connect(host='localhost',user='root',password='roshani1306',database='automobileshowroomdb')
curs=con.cursor()

form=cgi.FieldStorage()
id=form.getvalue("uid")
ps=form.getvalue("psw")

curs.execute("select * from users where userid='%s' and password='%s'" %(id,ps))
rec=curs.fetchone()

if rec:
    print("<html>")
    print("<head>")
    print("<meta http-equiv='refresh' content='0';url='login.html'/>")
    print("</head>")
    print("</html>")
    print("Login successfully")
else:
    print("<h2>Sorry authentication failed</h2>")
    print("<a href='index.html'>Home</a>>")


con.close()